package tutien.mod;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public class TuTienModClient implements ClientModInitializer {
   private static TuTienModClient.Mode MODE;
   private boolean checkguiclick = false;
   private class_1703 checkgui = null;

   public void onInitializeClient() {
      ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
         dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("tct").then(ClientCommandManager.literal("on").executes((ctx) -> {
            MODE = TuTienModClient.Mode.TCT;
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(class_2561.method_43470("[TCT] ON"));
            return 1;
         }))).then(ClientCommandManager.literal("off").executes((ctx) -> {
            if (MODE == TuTienModClient.Mode.TCT) {
               MODE = TuTienModClient.Mode.NONE;
            }

            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(class_2561.method_43470("[TCT] OFF"));
            return 1;
         })));
         dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("ld").then(ClientCommandManager.literal("on").executes((ctx) -> {
            MODE = TuTienModClient.Mode.LD;
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(class_2561.method_43470("[LD] ON"));
            return 1;
         }))).then(ClientCommandManager.literal("off").executes((ctx) -> {
            if (MODE == TuTienModClient.Mode.LD) {
               MODE = TuTienModClient.Mode.NONE;
            }

            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(class_2561.method_43470("[LD] OFF"));
            return 1;
         })));
      });
      ClientTickEvents.END_CLIENT_TICK.register((client) -> {
         if (client.field_1724 != null) {
            this.ausprint(client);
            if (MODE != TuTienModClient.Mode.NONE && client.field_1761 != null) {
               if (!(client.field_1755 instanceof class_465)) {
                  this.checkguiclick = false;
                  this.checkgui = null;
               } else {
                  class_1703 handler = client.field_1724.field_7512;
                  if (handler != null) {
                     if (handler != this.checkgui) {
                        this.checkguiclick = false;
                        this.checkgui = handler;
                     }

                     if (!this.checkguiclick) {
                        if (MODE == TuTienModClient.Mode.TCT && this.clickk(client, handler, class_1802.field_8782)) {
                           this.checkguiclick = true;
                        }

                        if (MODE == TuTienModClient.Mode.LD && this.clickk(client, handler, class_1802.field_8638)) {
                           this.checkguiclick = true;
                        }

                     }
                  }
               }
            }
         }
      });
   }

   private void ausprint(class_310 client) {
      if (client.field_1755 == null) {
         class_746 player = client.field_1724;
         if (!player.method_5715()) {
            if (!player.method_5765()) {
               if (!player.method_5799()) {
                  if (player.method_7344().method_7586() > 6) {
                     class_304 forward = client.field_1690.field_1894;
                     if (forward.method_1434()) {
                        player.method_5728(true);
                     }

                  }
               }
            }
         }
      }
   }

   private boolean clickk(class_310 client, class_1703 handler, class_1792 target) {
      for(int i = 0; i < handler.field_7761.size(); ++i) {
         class_1735 slot = handler.method_7611(i);
         if (slot.method_7681() && slot.method_7677().method_31574(target)) {
            client.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7794, client.field_1724);
            return true;
         }
      }

      return false;
   }

   static {
      MODE = TuTienModClient.Mode.NONE;
   }

   @Environment(EnvType.CLIENT)
   private static enum Mode {
      NONE,
      TCT,
      LD;

      // $FF: synthetic method
      private static TuTienModClient.Mode[] $values() {
         return new TuTienModClient.Mode[]{NONE, TCT, LD};
      }
   }
}
