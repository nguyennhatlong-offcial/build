package tutien.mod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TuTienMod implements ModInitializer {
   public static final String MOD_ID = "tutienmod";
   public static final Logger LOGGER = LoggerFactory.getLogger("tutienmod");

   public void onInitialize() {
      LOGGER.info("Hello Fabric world!");
   }
}
